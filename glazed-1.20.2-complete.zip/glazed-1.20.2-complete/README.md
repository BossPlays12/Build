# Glazed Mod - Minecraft 1.20.2 Port

![Minecraft](https://img.shields.io/badge/Minecraft-1.20.2-brightgreen)
![Fabric](https://img.shields.io/badge/Fabric-0.15.0-blue)
![Java](https://img.shields.io/badge/Java-17-orange)

This is a port of the Glazed addon for Meteor Client from Minecraft 1.21.4 to 1.20.2.

---

## 📦 What's Included

This is a **COMPLETE, READY-TO-BUILD** project with:
- ✅ Full Java source code
- ✅ Configured Gradle build files
- ✅ Updated for Minecraft 1.20.2
- ✅ Updated for Java 17
- ✅ All dependencies configured
- ✅ Build scripts included

---

## 🎯 Quick Start

### Option 1: Pre-Built JAR (Easiest)
**If you just want to use the mod:**
1. Download `glazed-1.20.2-1.0.jar` from releases
2. Install Fabric Loader 0.15.0+ for MC 1.20.2
3. Install Meteor Client 0.5.5
4. Copy JAR to `.minecraft/mods/` folder
5. Play!

### Option 2: Build It Yourself

**On Computer (Windows/Mac/Linux):**
```bash
# 1. Make sure Java 17+ is installed
java -version

# 2. Build the mod
./gradlew build          # Linux/Mac
gradlew.bat build        # Windows

# 3. Find your mod in:
# build/libs/glazed-1.20.2-1.0.jar
```

**On Android (Advanced):**
See [MOBILE_BUILDING_GUIDE.md](MOBILE_BUILDING_GUIDE.md) for detailed instructions.

---

## 📋 Requirements

### To Build:
- **Java Development Kit**: JDK 17 or higher
- **Internet**: For downloading dependencies
- **Storage**: ~500MB free space
- **Time**: 5-15 minutes for first build

### To Use:
- **Minecraft Java Edition**: 1.20.2
- **Fabric Loader**: 0.15.0 or higher
- **Meteor Client**: 0.5.5 (1.20.2 version)

---

## 🔧 Building the Mod

### Windows:
```batch
gradlew.bat clean build
```

### Linux/Mac:
```bash
chmod +x gradlew
./gradlew clean build
```

### First Build Will:
1. Download Gradle (if needed)
2. Download Minecraft 1.20.2
3. Download Fabric mappings
4. Download dependencies (Meteor Client, etc.)
5. Compile the mod
6. Create JAR file

**Expected time:** 5-15 minutes (depends on internet speed)

---

## 📂 Project Structure

```
glazed-1.20.2-complete/
├── src/
│   ├── main/
│   │   ├── java/              # Java source code
│   │   │   └── com/nnpg/glazed/
│   │   │       ├── GlazedAddon.java
│   │   │       ├── modules/   # Addon modules
│   │   │       ├── mixins/    # Mixin classes
│   │   │       ├── settings/  # Custom settings
│   │   │       ├── utils/     # Utilities
│   │   │       └── gui/       # GUI widgets
│   │   └── resources/         # Assets & configs
│   │       ├── assets/
│   │       ├── fabric.mod.json
│   │       └── mixins.json
├── build.gradle               # Build configuration
├── gradle.properties          # Version settings
├── settings.gradle            # Gradle settings
└── gradlew                    # Build script

After building:
└── build/
    └── libs/
        └── glazed-1.20.2-1.0.jar  # Your mod!
```

---

## 🚀 Installation

### Step 1: Install Prerequisites

1. **Minecraft Java Edition 1.20.2**
   - Make sure you have the right version

2. **Fabric Loader**
   - Download from: https://fabricmc.net/use/
   - Run installer, select Minecraft 1.20.2

3. **Meteor Client**
   - Download version 0.5.5 for 1.20.2
   - From: https://meteorclient.com/
   - Place in `.minecraft/mods/`

### Step 2: Install Glazed Mod

Copy `glazed-1.20.2-1.0.jar` to your mods folder:

**Windows:**
```
%APPDATA%\.minecraft\mods\
```

**Mac:**
```
~/Library/Application Support/minecraft/mods/
```

**Linux:**
```
~/.minecraft/mods/
```

### Step 3: Launch Minecraft

1. Open Minecraft Launcher
2. Select Fabric 1.20.2 profile
3. Click Play
4. Press **Right-Shift** in-game to open Meteor Client
5. Check that Glazed is in the addons list

---

## 🔨 Development

### Setting Up IDE

**IntelliJ IDEA (Recommended):**
1. File → Open → Select this folder
2. Wait for Gradle to sync
3. Run configurations will be created automatically

**Eclipse:**
1. Import → Gradle → Existing Gradle Project
2. Select this folder

### Running in Development

```bash
./gradlew runClient
```

This launches Minecraft with your mod loaded for testing.

### Useful Commands

```bash
# Clean build files
./gradlew clean

# Build without running tests
./gradlew build -x test

# Generate Minecraft source for reference
./gradlew genSources

# See all available tasks
./gradlew tasks
```

---

## 📝 What Changed from 1.21.4 to 1.20.2

### Updated:
- ✅ Minecraft version: 1.21.4 → 1.20.2
- ✅ Java version: 21 → 17
- ✅ Fabric Loader: 0.16.7 → 0.15.0
- ✅ Yarn mappings: 1.21.4+build.1 → 1.20.2+build.4
- ✅ Meteor Client: 1.21.4-SNAPSHOT → 0.5.5-SNAPSHOT
- ✅ Build configuration: Gradle Kotlin DSL → Gradle Groovy

### Compatibility Notes:
- Most code should work without changes
- Some API methods may have different names
- If you encounter errors, check Meteor Client's 1.20.2 API

---

## ❓ Troubleshooting

### Build Fails with "Could not find meteor-client"
**Solution:**
```bash
./gradlew build --refresh-dependencies
```

### "Java version not supported"
**Solution:**
- Make sure JDK 17+ is installed
- Run: `java -version` to check

### Game Crashes on Launch
**Solution:**
1. Check you have Meteor Client 0.5.5 installed
2. Check all mods are for Minecraft 1.20.2
3. Look at `logs/latest.log` for specific error

### Mod Doesn't Show Up
**Solution:**
1. Verify you're using Fabric profile (not Forge)
2. Check mod is in correct mods folder
3. Open Meteor Client (Right-Shift) → Check addons tab

### Build Takes Forever
**Solution:**
- First build always takes longer (downloading dependencies)
- Subsequent builds will be much faster
- Make sure you have good internet connection

---

## 📱 Building on Mobile

Building Java mods on mobile is **extremely difficult** and not recommended.

**Options:**
1. **Use a computer** (recommended)
2. **Use Termux on Android** (advanced, see MOBILE_BUILDING_GUIDE.md)
3. **Use GitHub Actions** (build in cloud for free)
4. **Ask me to build it for you** (easiest)

See [MOBILE_BUILDING_GUIDE.md](MOBILE_BUILDING_GUIDE.md) for complete mobile instructions.

---

## 🤝 Credits

- **Original Author**: nnpg
- **Original Mod**: Glazed for Meteor Client 1.21.4
- **Website**: https://glazedclient.com
- **Discord**: https://discord.gg/TCQDpG8ByY
- **Port**: Adapted for Minecraft 1.20.2

---

## ⚖️ License

All Rights Reserved - Original license from Glazed mod applies.

---

## 🆘 Need Help?

1. **Building issues**: Check troubleshooting section above
2. **Mod usage**: Join Discord at https://discord.gg/TCQDpG8ByY
3. **Fabric help**: https://fabricmc.net/wiki/
4. **Meteor Client**: https://meteorclient.com/

---

## 🎮 Features

This mod includes all the original Glazed addon features:
- Custom modules for Meteor Client
- Additional automation features
- Enhanced GUI widgets
- Custom settings types
- Inventory utilities
- And more!

Press **Right-Shift** in-game to access Meteor Client and find Glazed modules.

---

**Enjoy the mod!** 🎉
